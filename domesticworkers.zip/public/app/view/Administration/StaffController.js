Ext.define('eworker.view.Administration.StaffController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.administration-staff'

});
