Ext.define('eworker.view.Administration.StaffModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.administration-staff',
    data: {
        name: 'eworker'
    }

});
