Ext.define('eworker.view.Worker.DashboardController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.worker-dashboard'

});
