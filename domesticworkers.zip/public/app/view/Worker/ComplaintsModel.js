Ext.define('eworker.view.worker.ComplaintsModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.worker-complaints',
    data: {
        name: 'eworker'
    }

});
