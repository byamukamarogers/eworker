Ext.define('eworker.view.worker.ComplaintFormModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.worker-complaintform'

});
