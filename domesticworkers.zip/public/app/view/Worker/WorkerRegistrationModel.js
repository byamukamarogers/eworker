Ext.define('eworker.view.Worker.WorkerRegistrationModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.worker-workerregistration',
    data: {
        name: 'eworker'
    }

});
