Ext.define('eworker.view.Worker.DashboardModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.worker-dashboard',
    data: {
        name: 'eworker'
    }

});
