Ext.define('eworker.view.Worker.WorkersModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.worker-workers',
    data: {
        name: 'eworker'
    }

});
