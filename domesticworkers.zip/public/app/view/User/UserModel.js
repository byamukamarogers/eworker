Ext.define('eworker.view.User.UserModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.user-user',
    data: {
        name: 'eworker'
    }

});
