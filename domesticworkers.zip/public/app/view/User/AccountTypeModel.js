Ext.define('eworker.view.User.AccountTypeModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.user-accounttype',
    data: {
        name: 'eworker'
    }

});
