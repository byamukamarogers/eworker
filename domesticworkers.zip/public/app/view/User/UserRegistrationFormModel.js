Ext.define('eworker.view.User.UserRegistrationFormModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.user-userregistrationform',
    data: {
        name: 'eworker'
    }

});
