Ext.define('eworker.view.Employer.EmployersModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.employer-employers',
    data: {
        name: 'eworker'
    }

});
