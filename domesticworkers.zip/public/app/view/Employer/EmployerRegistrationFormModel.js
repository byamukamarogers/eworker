Ext.define('eworker.view.Employer.EmployerRegistrationFormModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.employer-employerregistrationform',
    data: {
        name: 'eworker'
    }

});
