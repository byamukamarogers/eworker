Ext.define('eworker.view.Jobs.ApplicationsController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.jobs-applications',
    onAfterRender: async function () {
        let data = this.getView().formData;
        if (data) {
            this.getViewModel().setData(data);
        }
        await this.loadJobApplications();
        await this.loadJobs();
    },

    loadJobs: async function () {
        let combo = this.lookupReference('grdJobsApplied');
        let response = await Ext.Ajax.request({ url: '/job', method: 'get' });
        if (response.responseText) {
            let records = JSON.parse(response.responseText);
            for (let i = 0; i < records.length; i++) {
                records[i].fullName = records[i].Employer.firstName + ' ' + records[i].Employer.lastName;
                records[i].telephone = records[i].Employer.telephone
            }
            let store = Ext.create('Ext.data.Store', { data: records });
            combo.setStore(store);
            store.load();
        }
    },
    loadJobApplications: async function () {
        let combo = this.lookupReference('grdJobApplications');
        let response = await Ext.Ajax.request({ url: '/jobApplication', method: 'get' });
        if (response.responseText) {
            let records = JSON.parse(response.responseText);
            for (let i = 0; i < records.length; i++) {
                records[i].fullName = records[i].Worker.firstName+ ' '+records[i].Worker.lastName;
                records[i].telephone = records[i].Worker.telephone;
            }
            let store = Ext.create('Ext.data.Store', { data: records });
            combo.setStore(store);
            store.load();
        }
    },

});
