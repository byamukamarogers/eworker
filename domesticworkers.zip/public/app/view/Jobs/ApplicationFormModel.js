Ext.define('eworker.view.Jobs.ApplicationFormModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.jobs-applicationform',
    data: {
        name: 'eworker'
    }

});
