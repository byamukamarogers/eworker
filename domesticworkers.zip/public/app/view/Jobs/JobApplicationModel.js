Ext.define('eworker.view.Jobs.JobApplicationModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.jobs-jobapplication',
    data: {
        name: 'eworker'
    }

});
