Ext.define('eworker.view.Jobs.ApplicationFormController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.jobs-applicationform'

});
