Ext.define('eworker.view.Jobs.ApplicationsModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.jobs-applications',
    data: {
        name: 'eworker'
    }

});
