Ext.define('eworker.view.Jobs.JobPostFormModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.jobs-jobpostform',
    data: {
        name: 'eworker'
    }

});
