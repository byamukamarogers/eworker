Ext.define('eworker.view.jobs.JobCategoryModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.jobs-jobcategory',
    data: {
        name: 'eworker'
    }

});
