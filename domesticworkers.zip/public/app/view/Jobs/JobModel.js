Ext.define('eworker.view.Jobs.JobModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.jobs-job',
    data: {
        name: 'eworker'
    }

});
