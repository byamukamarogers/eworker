Ext.define('eworker.view.Staff.StaffRegistryModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.staffregistry',
    data: {
        name: 'ehealth'
    }

});
