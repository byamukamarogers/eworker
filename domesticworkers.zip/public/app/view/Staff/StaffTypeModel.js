Ext.define('eworker.view.Staff.StaffTypeModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.user-stafftype',
    data: {
        name: 'eworker'
    }

});
