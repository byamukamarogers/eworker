Ext.define('eworker.view.Staff.StaffViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.staffview'

});