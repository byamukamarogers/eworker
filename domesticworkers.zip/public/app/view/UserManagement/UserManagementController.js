Ext.define('eworker.view.UserManagement.UserManagementController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.usermanagement'

});
