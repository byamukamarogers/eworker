Ext.define('eworker.view.UserManagement.UserRegistrationModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.userregistration',
    data: {
        name: 'ehealth'
    }

});
