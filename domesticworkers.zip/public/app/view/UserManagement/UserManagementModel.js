Ext.define('eworker.view.UserManagement.UserManagementModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.usermanagement',
    data: {
        name: 'ehealth'
    }

});
