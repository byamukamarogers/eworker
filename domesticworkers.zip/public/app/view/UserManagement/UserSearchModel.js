Ext.define('eworker.view.UserManagement.UserSearchModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.usersearch',
    data: {
        name: 'ehealth'
    }

});
